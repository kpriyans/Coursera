export const LOGIN_ADMIN = 'LOGIN_ADMIN';
export const IS_LOADING = 'IS_LOADING';
export const LOGOUT = 'LOGOUT';
export const LOGIN_FAILED = 'LOGIN_FAILED';